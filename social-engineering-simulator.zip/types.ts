
export enum AttackType {
  EMAIL = 'Email Phishing',
  SMS = 'SMS Scam (Smishing)',
  CALL = 'Voice Scam (Vishing)',
  SUPPORT = 'Fake Tech Support'
}

export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export interface Choice {
  text: string;
  feedback: string;
  riskLevel: RiskLevel;
  scoreImpact: number;
}

export interface ScenarioStep {
  message: string;
  sender: string;
  choices: Choice[];
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  type: AttackType;
  steps: ScenarioStep[];
}

export interface SimulationState {
  currentScenario: Scenario | null;
  stepIndex: number;
  score: number;
  history: {
    step: ScenarioStep;
    choice: Choice;
  }[];
  isComplete: boolean;
}
