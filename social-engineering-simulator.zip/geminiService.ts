
import { GoogleGenAI, Type } from "@google/genai";
import { AttackType, RiskLevel, Scenario } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SCENARIO_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    id: { type: Type.STRING },
    name: { type: Type.STRING },
    description: { type: Type.STRING },
    steps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          sender: { type: Type.STRING },
          message: { type: Type.STRING },
          choices: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                feedback: { type: Type.STRING },
                riskLevel: { type: Type.STRING, description: 'One of: Low, Medium, High' },
                scoreImpact: { type: Type.NUMBER }
              },
              required: ['text', 'feedback', 'riskLevel', 'scoreImpact']
            }
          }
        },
        required: ['sender', 'message', 'choices']
      }
    }
  },
  required: ['id', 'name', 'description', 'steps']
};

export const generateScenario = async (type: AttackType): Promise<Scenario> => {
  const prompt = `Generate a highly realistic social engineering scenario for the attack type: ${type}. 
  The scenario should be a multi-step sequence (3 steps). 
  Each step should provide a message from an attacker and 3 choices for the user.
  Choices should include:
  1. A correct/secure choice (Low risk, score impact 0).
  2. A dangerous choice (High risk, score impact -30).
  3. A naive but cautious choice (Medium risk, score impact -10).
  
  Provide educational feedback explaining why the choice was good or bad.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: SCENARIO_SCHEMA,
    },
  });

  try {
    const data = JSON.parse(response.text || '{}');
    return {
      ...data,
      type
    };
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Failed to generate simulation scenario.");
  }
};
