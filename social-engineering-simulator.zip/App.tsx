
import React, { useState, useCallback } from 'react';
import { 
  ShieldAlert, 
  Mail, 
  MessageSquare, 
  PhoneCall, 
  LifeBuoy, 
  ArrowRight, 
  RefreshCcw, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle,
  TrendingUp
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { AttackType, Scenario, SimulationState, RiskLevel, Choice } from './types';
import { generateScenario } from './geminiService';

const App: React.FC = () => {
  const [view, setView] = useState<'welcome' | 'selection' | 'loading' | 'simulator' | 'results'>('welcome');
  const [state, setState] = useState<SimulationState>({
    currentScenario: null,
    stepIndex: 0,
    score: 100,
    history: [],
    isComplete: false
  });
  const [lastFeedback, setLastFeedback] = useState<Choice | null>(null);

  const startTraining = () => setView('selection');

  const selectScenario = async (type: AttackType) => {
    setView('loading');
    try {
      const scenario = await generateScenario(type);
      setState({
        currentScenario: scenario,
        stepIndex: 0,
        score: 100,
        history: [],
        isComplete: false
      });
      setView('simulator');
    } catch (error) {
      alert("Failed to connect to simulation server. Please try again.");
      setView('selection');
    }
  };

  const handleChoice = (choice: Choice) => {
    setLastFeedback(choice);
  };

  const proceedToNextStep = () => {
    if (!state.currentScenario || !lastFeedback) return;

    const newHistory = [...state.history, { 
      step: state.currentScenario.steps[state.stepIndex], 
      choice: lastFeedback 
    }];
    const newScore = Math.max(0, state.score + lastFeedback.scoreImpact);
    const nextStep = state.stepIndex + 1;
    const isComplete = nextStep >= state.currentScenario.steps.length;

    setState(prev => ({
      ...prev,
      stepIndex: nextStep,
      score: newScore,
      history: newHistory,
      isComplete: isComplete
    }));
    setLastFeedback(null);

    if (isComplete) setView('results');
  };

  const reset = () => {
    setView('welcome');
    setState({
      currentScenario: null,
      stepIndex: 0,
      score: 100,
      history: [],
      isComplete: false
    });
    setLastFeedback(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={reset}>
          <div className="bg-indigo-600 p-2 rounded-lg">
            <ShieldAlert className="text-white w-6 h-6" />
          </div>
          <h1 className="font-bold text-xl tracking-tight text-slate-800 hidden sm:block">SecAware Simulator</h1>
        </div>
        {view === 'simulator' && (
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Awareness Score</span>
              <span className={`font-bold text-lg ${state.score > 70 ? 'text-green-600' : state.score > 40 ? 'text-amber-500' : 'text-red-500'}`}>
                {state.score}%
              </span>
            </div>
            <div className="w-32 bg-slate-200 h-2 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${state.score > 70 ? 'bg-green-500' : state.score > 40 ? 'bg-amber-400' : 'bg-red-500'}`} 
                style={{ width: `${state.score}%` }} 
              />
            </div>
          </div>
        )}
      </header>

      <main className="flex-1 container mx-auto px-4 py-8 max-w-5xl">
        {view === 'welcome' && <WelcomeView onStart={startTraining} />}
        {view === 'selection' && <SelectionView onSelect={selectScenario} />}
        {view === 'loading' && <LoadingView />}
        {view === 'simulator' && state.currentScenario && (
          <SimulatorView 
            state={state} 
            onChoice={handleChoice} 
            lastFeedback={lastFeedback}
            onProceed={proceedToNextStep}
          />
        )}
        {view === 'results' && <ResultsView state={state} onRestart={reset} />}
      </main>

      {/* Footer */}
      <footer className="py-6 border-t border-slate-200 bg-white text-center text-slate-500 text-sm">
        &copy; 2024 Cybersecurity Research Lab. Interactive Social Engineering Experiment.
      </footer>
    </div>
  );
};

const WelcomeView: React.FC<{ onStart: () => void }> = ({ onStart }) => (
  <div className="max-w-3xl mx-auto text-center py-12">
    <div className="mb-8 inline-flex p-4 bg-indigo-50 rounded-full">
      <ShieldAlert className="w-16 h-16 text-indigo-600" />
    </div>
    <h1 className="text-5xl font-black text-slate-900 mb-6 tracking-tight">
      Are You Resilient to <span className="text-indigo-600 underline decoration-indigo-200 decoration-8 underline-offset-4">Manipulation?</span>
    </h1>
    <p className="text-xl text-slate-600 mb-10 leading-relaxed">
      Social engineering is the art of manipulating people into giving up confidential information. 
      This simulator provides realistic phishing, smishing, and vishing scenarios used by real-world hackers 
      to test your reflexes and awareness.
    </p>
    <div className="grid md:grid-cols-3 gap-6 mb-12">
      <FeatureCard 
        icon={<Mail className="text-blue-500" />} 
        title="Phishing Email" 
        desc="Detect deceptive emails and fake login pages." 
      />
      <FeatureCard 
        icon={<MessageSquare className="text-green-500" />} 
        title="Smishing SMS" 
        desc="Identify malicious links in urgent text messages." 
      />
      <FeatureCard 
        icon={<PhoneCall className="text-red-500" />} 
        title="Vishing Calls" 
        desc="Practice handling impersonation & social pressure." 
      />
    </div>
    <button 
      onClick={onStart}
      className="group bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-indigo-200 transition-all flex items-center gap-2 mx-auto"
    >
      Begin Awareness Training
      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
    </button>
  </div>
);

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; desc: string }> = ({ icon, title, desc }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm text-left">
    <div className="mb-4">{icon}</div>
    <h3 className="font-bold text-slate-800 mb-2">{title}</h3>
    <p className="text-slate-500 text-sm">{desc}</p>
  </div>
);

const SelectionView: React.FC<{ onSelect: (t: AttackType) => void }> = ({ onSelect }) => (
  <div className="max-w-4xl mx-auto">
    <h2 className="text-3xl font-bold text-slate-900 mb-2">Choose Your Training Module</h2>
    <p className="text-slate-500 mb-8">Each module contains a unique social experiment to evaluate your security decision making.</p>
    
    <div className="grid md:grid-cols-2 gap-6">
      <ScenarioOption 
        title="Corporate Phishing" 
        desc="A sophisticated email attack targeting IT staff. Can you spot the 'official' IT request?" 
        type={AttackType.EMAIL}
        icon={<Mail className="w-8 h-8" />}
        color="bg-blue-500"
        onSelect={onSelect}
      />
      <ScenarioOption 
        title="Fake Tech Support" 
        desc="Remote desktop and urgent system error scams. Designed for IT pros and staff." 
        type={AttackType.SUPPORT}
        icon={<LifeBuoy className="w-8 h-8" />}
        color="bg-amber-500"
        onSelect={onSelect}
      />
      <ScenarioOption 
        title="Executive Impersonation" 
        desc="Urgent 'CEO' request over SMS. Handling high-pressure requests from superiors." 
        type={AttackType.SMS}
        icon={<MessageSquare className="w-8 h-8" />}
        color="bg-green-500"
        onSelect={onSelect}
      />
      <ScenarioOption 
        title="Voice Fraud (Vishing)" 
        desc="A convincing phone call from a 'bank representative' or 'vendor'." 
        type={AttackType.CALL}
        icon={<PhoneCall className="w-8 h-8" />}
        color="bg-rose-500"
        onSelect={onSelect}
      />
    </div>
  </div>
);

const ScenarioOption: React.FC<{ 
  title: string; 
  desc: string; 
  type: AttackType; 
  icon: React.ReactNode; 
  color: string;
  onSelect: (t: AttackType) => void 
}> = ({ title, desc, type, icon, color, onSelect }) => (
  <button 
    onClick={() => onSelect(type)}
    className="group flex flex-col items-start p-8 bg-white border border-slate-200 rounded-3xl text-left hover:border-indigo-400 hover:shadow-xl transition-all relative overflow-hidden"
  >
    <div className={`${color} p-4 rounded-2xl text-white mb-6 group-hover:scale-110 transition-transform`}>
      {icon}
    </div>
    <h3 className="text-xl font-bold text-slate-900 mb-3">{title}</h3>
    <p className="text-slate-500 mb-6 leading-relaxed">{desc}</p>
    <div className="mt-auto flex items-center gap-2 text-indigo-600 font-bold">
      Launch Simulation <ArrowRight className="w-4 h-4" />
    </div>
    <div className="absolute top-0 right-0 p-4 opacity-5">
      {icon}
    </div>
  </button>
);

const LoadingView: React.FC = () => (
  <div className="flex flex-col items-center justify-center py-24">
    <div className="relative">
      <RefreshCcw className="w-16 h-16 text-indigo-600 animate-spin" />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-8 h-8 bg-white rounded-full"></div>
      </div>
    </div>
    <h3 className="text-2xl font-bold text-slate-800 mt-8">Crafting Your Simulation...</h3>
    <p className="text-slate-500 mt-2">Gemini AI is generating realistic attack vectors based on current trends.</p>
  </div>
);

const SimulatorView: React.FC<{ 
  state: SimulationState; 
  onChoice: (c: Choice) => void;
  lastFeedback: Choice | null;
  onProceed: () => void;
}> = ({ state, onChoice, lastFeedback, onProceed }) => {
  const currentStep = state.currentScenario!.steps[state.stepIndex];
  const type = state.currentScenario!.type;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <span className="bg-slate-200 text-slate-600 px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase">
            Step {state.stepIndex + 1} of {state.currentScenario!.steps.length}
          </span>
          <h2 className="text-2xl font-bold text-slate-800 mt-2">{state.currentScenario?.name}</h2>
        </div>
        <div className="text-sm font-medium text-slate-500">
          Target Mode: <span className="text-slate-800">{type}</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Interaction Pane */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden min-h-[400px] flex flex-col">
            {/* Context Header */}
            <div className="bg-slate-50 border-b border-slate-200 p-4 flex items-center gap-3">
              {type === AttackType.EMAIL && <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center"><Mail className="w-5 h-5 text-blue-600" /></div>}
              {type === AttackType.SMS && <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center"><MessageSquare className="w-5 h-5 text-green-600" /></div>}
              {type === AttackType.CALL && <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center"><PhoneCall className="w-5 h-5 text-rose-600" /></div>}
              {type === AttackType.SUPPORT && <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center"><LifeBuoy className="w-5 h-5 text-amber-600" /></div>}
              
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase leading-none">From</p>
                <p className="font-bold text-slate-800">{currentStep.sender}</p>
              </div>
            </div>

            {/* Message Area */}
            <div className="flex-1 p-8 bg-white">
              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 relative">
                <p className="text-slate-700 leading-relaxed whitespace-pre-wrap italic">
                  "{currentStep.message}"
                </p>
                <div className="absolute -left-2 top-6 w-4 h-4 bg-slate-50 border-l border-b border-slate-100 transform rotate-45"></div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-6 bg-slate-50 border-t border-slate-200">
              {!lastFeedback ? (
                <div className="space-y-3">
                  <p className="text-sm font-bold text-slate-500 mb-2 uppercase">How do you respond?</p>
                  {currentStep.choices.map((choice, idx) => (
                    <button 
                      key={idx}
                      onClick={() => onChoice(choice)}
                      className="w-full text-left p-4 bg-white border border-slate-200 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 transition-all font-medium text-slate-700 shadow-sm group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-full border border-slate-300 flex items-center justify-center text-xs font-bold group-hover:border-indigo-500 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          {String.fromCharCode(65 + idx)}
                        </div>
                        {choice.text}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="flex justify-end">
                  <button 
                    onClick={onProceed}
                    className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
                  >
                    Proceed to Next Phase <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Feedback Pane (Sticky) */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-4">
            {lastFeedback ? (
              <div className={`p-6 rounded-3xl border-2 transition-all animate-in slide-in-from-right-4 duration-500 shadow-xl ${
                lastFeedback.riskLevel === RiskLevel.LOW ? 'bg-green-50 border-green-200' :
                lastFeedback.riskLevel === RiskLevel.MEDIUM ? 'bg-amber-50 border-amber-200' :
                'bg-rose-50 border-rose-200'
              }`}>
                <div className="flex items-center gap-3 mb-4">
                  {lastFeedback.riskLevel === RiskLevel.LOW && <CheckCircle2 className="text-green-600 w-8 h-8" />}
                  {lastFeedback.riskLevel === RiskLevel.MEDIUM && <AlertTriangle className="text-amber-600 w-8 h-8" />}
                  {lastFeedback.riskLevel === RiskLevel.HIGH && <XCircle className="text-rose-600 w-8 h-8" />}
                  <div>
                    <h4 className="font-black text-slate-900 leading-none uppercase text-sm tracking-widest">Risk Level</h4>
                    <p className={`text-xl font-black ${
                      lastFeedback.riskLevel === RiskLevel.LOW ? 'text-green-700' :
                      lastFeedback.riskLevel === RiskLevel.MEDIUM ? 'text-amber-700' :
                      'text-rose-700'
                    }`}>{lastFeedback.riskLevel}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <p className="text-slate-700 leading-relaxed font-medium">
                    {lastFeedback.feedback}
                  </p>
                  <div className={`p-3 rounded-xl text-center font-bold text-sm ${
                    lastFeedback.scoreImpact >= 0 ? 'bg-green-100 text-green-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    Awareness Adjustment: {lastFeedback.scoreImpact > 0 ? '+' : ''}{lastFeedback.scoreImpact} pts
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center text-center bg-white/50">
                <ShieldAlert className="w-12 h-12 text-slate-300 mb-4" />
                <p className="text-slate-400 font-medium">Choose an action to see AI-driven security analysis.</p>
              </div>
            )}

            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-500" />
                Security Tip
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed italic">
                {lastFeedback?.riskLevel === RiskLevel.HIGH 
                  ? "Always verify unexpected requests via a separate, known communication channel before taking any action."
                  : "Social engineers often use 'urgency' and 'authority' to bypass your critical thinking. Stay calm."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ResultsView: React.FC<{ state: SimulationState; onRestart: () => void }> = ({ state, onRestart }) => {
  const chartData = state.history.map((h, i) => ({
    name: `Step ${i + 1}`,
    score: h.choice.scoreImpact,
    risk: h.choice.riskLevel
  }));

  const getPerformanceMessage = () => {
    if (state.score >= 90) return { title: "Resilient Protector", desc: "Your awareness is top-notch. You identified the subtle cues of manipulation easily.", color: "text-green-600" };
    if (state.score >= 70) return { title: "Vigilant User", desc: "Good job. You caught most issues but were slightly swayed by certain tactics.", color: "text-blue-600" };
    if (state.score >= 40) return { title: "Target at Risk", desc: "You are susceptible to social pressure and urgency. More training is recommended.", color: "text-amber-600" };
    return { title: "Compromised", desc: "A real attacker would have succeeded. You need to significantly improve your security posture.", color: "text-rose-600" };
  };

  const perf = getPerformanceMessage();

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-[40px] border border-slate-200 shadow-2xl overflow-hidden">
        <div className="bg-slate-900 py-16 px-8 text-center text-white relative">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <ShieldAlert className="w-64 h-64" />
          </div>
          <p className="text-indigo-400 font-bold tracking-[0.2em] uppercase mb-4">Simulation Result</p>
          <h2 className="text-5xl font-black mb-6">Final Score: {state.score}%</h2>
          <div className="max-w-xl mx-auto">
            <h3 className={`text-2xl font-bold mb-3 ${perf.color}`}>{perf.title}</h3>
            <p className="text-slate-400 text-lg leading-relaxed">{perf.desc}</p>
          </div>
        </div>

        <div className="p-8 md:p-12 space-y-12">
          {/* Chart Section */}
          <section>
            <h4 className="text-xl font-bold text-slate-800 mb-8">Interaction Analysis</h4>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Score Impact', angle: -90, position: 'insideLeft' }} />
                  <Tooltip 
                    cursor={{fill: 'transparent'}}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg">
                            <p className="font-bold text-slate-800">{payload[0].payload.name}</p>
                            <p className="text-sm">Risk: <span className="font-bold">{payload[0].payload.risk}</span></p>
                            <p className="text-sm font-bold text-indigo-600">Impact: {payload[0].value}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="score">
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.score >= 0 ? '#10b981' : entry.score <= -20 ? '#f43f5e' : '#f59e0b'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          {/* Detailed History */}
          <section>
            <h4 className="text-xl font-bold text-slate-800 mb-6">Step-by-Step Review</h4>
            <div className="space-y-4">
              {state.history.map((h, i) => (
                <div key={i} className="flex gap-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center font-bold text-slate-400 shadow-sm">
                      {i + 1}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Your Choice</p>
                    <p className="font-bold text-slate-800">"{h.choice.text}"</p>
                    <p className="text-slate-600 text-sm italic">"{h.choice.feedback}"</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="pt-8 flex justify-center">
            <button 
              onClick={onRestart}
              className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl flex items-center gap-3"
            >
              <RefreshCcw className="w-5 h-5" />
              Try Another Scenario
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
